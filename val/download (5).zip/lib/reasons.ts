import data from './reasons.json';

export const Reasons: string[] = data.reasons;
