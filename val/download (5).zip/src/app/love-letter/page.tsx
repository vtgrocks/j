"use client";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Header } from "@/components/header";

const loveLetter = `My Dearest Valentine,

From the moment you walked into my life, everything changed. You brought a light and a joy I had never known before. Every day with you is a gift, an adventure, a new reason to smile.

I love the way you laugh, the way you think, the way you see the world. I love the quiet moments we share and the loud, crazy ones too. You make the ordinary extraordinary.

Thank you for being you, for being mine. My love for you is deeper than words can say.

Forever and always,
Your Valentine`;

export default function LoveLetterPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1">
        <div className="container mx-auto py-12 px-4">
          <div className="text-center mb-12">
            <h1 className="text-5xl md:text-6xl font-headline text-primary">
              A Love Letter
            </h1>
            <p className="text-lg text-muted-foreground mt-2">
              A special message, written from the heart.
            </p>
          </div>

          <div className="flex justify-center">
            <Card className="w-full max-w-2xl">
              <CardHeader>
                <CardTitle className="font-headline text-2xl text-center">Your Letter</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="w-full prose dark:prose-invert whitespace-pre-wrap font-body text-card-foreground text-base leading-relaxed">
                  {loveLetter}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
