import Image from "next/image";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { Card } from "@/components/ui/card";
import { Header } from "@/components/header";

export default function PicturesPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1">
        <div className="container mx-auto py-12 px-4">
          <div className="text-center mb-12">
            <h1 className="text-5xl md:text-6xl font-headline text-primary">
              Our Memories
            </h1>
            <p className="text-lg text-muted-foreground mt-2">
              Every picture tells a part of our story.
            </p>
          </div>
          <div className="columns-1 sm:columns-2 lg:columns-3 gap-4 space-y-4">
            {PlaceHolderImages.map((image) => (
              <div key={image.id} className="break-inside-avoid">
                <Card className="overflow-hidden group rounded-lg shadow-lg">
                  <Image
                    src={image.imageUrl}
                    alt={image.description}
                    width={600}
                    height={400}
                    data-ai-hint={image.imageHint}
                    className="w-full h-auto object-cover transform transition-transform duration-500 group-hover:scale-110"
                  />
                </Card>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
