import { config } from 'dotenv';
config();

import '@/ai/flows/generate-personalized-love-letter.ts';
